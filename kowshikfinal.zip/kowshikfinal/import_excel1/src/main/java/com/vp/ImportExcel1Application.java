package com.vp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImportExcel1Application {

	public static void main(String[] args) {
		SpringApplication.run(ImportExcel1Application.class, args);
	}

}
