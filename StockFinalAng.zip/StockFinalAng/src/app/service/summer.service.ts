import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { summaryModel } from 'src/entity/summaryModel';

@Injectable({
  providedIn: 'root'
})
export class SummerService {


  constructor(private http: HttpClient){

  }

  summary1(){
 
    return this.http.get<summaryModel>("http://localhost:9001/summary", {observe: 'response'});
  }
}
