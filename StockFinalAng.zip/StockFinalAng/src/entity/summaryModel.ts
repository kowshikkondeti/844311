export interface summaryModel{
    toDate:Date,
    fromDate:Date;
    noOfRecord:number,
    stockExchange:Date
}