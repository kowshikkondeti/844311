import { Component, OnInit } from '@angular/core';
import { SummerService } from '../service/summer.service';
import { summaryModel } from 'src/entity/summaryModel';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {
  sm:summaryModel;

  constructor(private service:SummerService) { }

  ngOnInit() {
    this.service.summary1().subscribe(data=>{
      this.sm=data.body;
      console.log(data.body)
      
    })
    }
    
  }

