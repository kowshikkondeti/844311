import { Injectable } from '@angular/core';
import { HttpResponse, HttpClient } from '@angular/common/http';
import { UserModel } from 'src/entity/UserModel';
import { Observable } from 'rxjs';
type EntityResponseType = HttpResponse<UserModel[]>;

@Injectable({
  providedIn: 'root'
})

export class UserService {

  constructor(private http:HttpClient) { }
  getAllUser():Observable<EntityResponseType>{
    //return this.http.get<StudentModel[]>("http://localhost:8084/students", {observe: 'response'});
    return this.http.get<UserModel[]>("http://localhost:8094/users", {observe: 'response'});
}

saveUser(userModel:UserModel){
   return this.http.post<UserModel>("http://localhost:8094/user", userModel, {observe: 'response'});
}

}
