import { Component, OnInit } from '@angular/core';
import { UserModel } from 'src/entity/UserModel';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user:UserModel[];
  myForm:FormGroup

  constructor(private service:UserService, private router:Router){}
  ngOnInit(): void {
    this.service.getAllUser().subscribe(data => {
         this.user = data.body;
         console.log(data.body)
    });
    {
    this.myForm=new FormGroup({
      uname:new FormControl('',Validators.required),
      pass:new FormControl('',Validators.required),
      mail:new FormControl('',Validators.required),
      no:new FormControl('',Validators.required)
     
    });
  }
    
  
}
  onSubmit(myForm: FormGroup)
{
  let usera:UserModel={
    uid:myForm.value.uid,
    username:myForm.value.uname,
    password:myForm.value.pass,
    // 
     type:'user',
    email:myForm.value.mail,
    mobile:myForm.value.no,
    // 
   //confirmed:false
  }
  this.service.saveUser(usera).subscribe(data =>{
    console.log(data.body);
      });
      this.router.navigate(['/login']);
      
} 
}
