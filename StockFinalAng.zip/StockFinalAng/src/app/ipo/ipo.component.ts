import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { IpoService } from '../service/ipo.service';
import { IpoModel } from 'src/entity/IpoModel';

@Component({
  selector: 'app-ipo',
  templateUrl: './ipo.component.html',
  styleUrls: ['./ipo.component.css']
})
export class IpoComponent implements OnInit {
  myForm: FormGroup;
  constructor(private service: IpoService) { }

  ngOnInit(): void {

    this.myForm = new FormGroup({
      name: new FormControl(""),
      brief: new FormControl(""),
      address: new FormControl(""),
      shares: new FormControl(""),
      remark: new FormControl("")
    });
  }
  onSubmit(form: FormGroup) {

    let ip: IpoModel = {

      company_name: form.value.name,
      stock_id: form.value.brief,
      price_per_share: form.value.address,
      no_of_shares: form.value.shares,
      remarks: form.value.remark
    }

    this.service.saveIpo(ip).subscribe(data => {
      console.log(data)
    })

  }
  notify() {
    alert("Data is Saved");
  }

}
