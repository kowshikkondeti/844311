import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule,ReactiveFormsModule} from '@angular/forms'
import { Routes, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import {CompanyService } from './service/company.service';

import { ChartsModule } from 'ng2-charts';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import {UserService } from './service/user.service';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminlandingComponent } from './adminlanding/adminlanding.component';
import { ImportdataComponent } from './importdata/importdata.component';
import { ManagecompanyComponent } from './managecompany/managecompany.component';
import { ManageexchangeComponent } from './manageexchange/manageexchange.component';
import { CreatecompanyComponent } from './createcompany/createcompany.component';
import { UserlandingComponent } from './userlanding/userlanding.component';

import { UpdatecompanyComponent } from './updatecompany/updatecompany.component';
import { IpoComponent } from './ipo/ipo.component';
import { CompareSectorComponent } from './compare-sector/compare-sector.component';
import { OtherComponent } from './other/other.component';
import { MyBarChartComponent } from './my-bar-chart/my-bar-chart.component';
import { MyPieChartComponent } from './my-pie-chart/my-pie-chart.component';
import { HomeComponent } from './home/home.component';
import { SummaryComponent } from './summary/summary.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    AdminlandingComponent,
    ImportdataComponent,
    ManagecompanyComponent,
    ManageexchangeComponent,
    CreatecompanyComponent,
    UserlandingComponent,
    
    UpdatecompanyComponent,
    
    IpoComponent,
    
    
    
    CompareSectorComponent,
    
    OtherComponent,
    
    MyBarChartComponent,
    
    MyPieChartComponent,
    
    HomeComponent,
    
    SummaryComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
     RouterModule,
     ReactiveFormsModule,
     ChartsModule,
     HttpClientModule
  ],
  providers: [UserService,
    CompanyService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
